#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Vicon UDP Object Stream :: Single-object filter

Run with: python track_ghost1.py --ip 0.0.0.0 --port 51001

Only prints (x, y, z, rx, ry, rz) when objectName == "ghost1".
Position is in meters, rotation in radians.
"""

import socket
import struct
import sys
from argparse import ArgumentParser
from time import time, sleep

class ViconUDPParser:
    ITEM_SIZE = 72  # bytes per object payload (Trans+RotXZY – 6×8, plus header)
    OBJECT_NAME_BYTES = 24
    HEADER_FMT = '<iBBh'   # frameNumber (int32), itemsInBlock (uint8), itemID (uint8), itemDataSize (int16)
    HEADER_SIZE = struct.calcsize(HEADER_FMT)

    def __init__(self, bind_ip="0.0.0.0", bind_port=51001, block_size=256):
        self.sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        self.sock.bind((bind_ip, bind_port))
        self.block_size = block_size

    def close(self):
        self.sock.close()

    def get_object_pose(self, target_name: str = "ghost1", timeout_sec: float = None):
        """
        Blocks until it receives a valid block whose object name matches target_name.
        Returns (x, y, z, rx, ry, rz), or None if timed out.
        """
        self.sock.settimeout(timeout_sec)
        try:
            data, addr = self.sock.recvfrom(self.block_size)
        except socket.timeout:
            return None
        if len(data) < self.HEADER_SIZE + self.ITEM_SIZE:
            # too small: ignore
            return None

        frame_num, items, item_id, data_size = struct.unpack_from('<iBBh', data, 0)
        if item_id != 0 or data_size != self.ITEM_SIZE:
            # not object data, or not expected size: skip
            return None

        # bytes 8–31: object name, ASCII, null-padded
        raw = data[self.HEADER_SIZE : self.HEADER_SIZE + self.OBJECT_NAME_BYTES]
        obj_name = raw.partition(b'\x00')[0].decode('ascii', errors='ignore').strip()

        if obj_name != target_name:
            return None

        base = self.HEADER_SIZE + self.OBJECT_NAME_BYTES
        trans = struct.unpack_from('<ddd', data, base)     # X,Y,Z (raw: mm)
        rot = struct.unpack_from('<ddd', data, base + 3*8)  # Rx,Ry,Rz in radians

        x, y, z = (trans[0] / 1000.0, trans[1] / 1000.0, trans[2] / 1000.0)
        rx, ry, rz = rot

        return (x, y, z, rx, ry, rz)

def main():
    parser = ArgumentParser(description="Track only ghost1 via Vicon UDP object stream.")
    parser.add_argument('--ip', default="0.0.0.0", help="Local IP to bind (default: 0.0.0.0)")
    parser.add_argument('--port', type=int, default=51001, help="UDP port to listen on (default: 51001)")
    parser.add_argument('--timeout', type=float, default=None,
                        help="Socket timeout in seconds (optional)")
    parser.add_argument('--object', default="ghost1", help="Name of Vicon object to filter")
    parser.add_argument('--block-size', type=int, choices=[256,512,1024], default=256,
                        help="Datagram block size set in Tracker UDP settings")
    args = parser.parse_args()

    parser_ = ViconUDPParser(bind_ip=args.ip, bind_port=args.port, block_size=args.block_size)
    print(f"Listening for object '{args.object}' on {args.ip}:{args.port} (block size {args.block_size})")

    try:
        while True:
            pose = parser_.get_object_pose(target_name=args.object, timeout_sec=args.timeout)
            if pose is None:
                if args.timeout is not None:
                    print(f"[timeout after {args.timeout:.2f} s: no '{args.object}' frame]", file=sys.stderr)
                    parser_.close()
                    return 1
                else:
                    continue
            x, y, z, rx, ry, rz = pose
            # timestamp using time.time(); you can switch to perf_counter if needed
            print(f"time {time():.3f}: {args.object} pose → "
                  f"pos=({x:.3f}, {y:.3f}, {z:.3f}) m, "
                  f"rot=({rx:.4f}, {ry:.4f}, {rz:.4f}) rad")
    except KeyboardInterrupt:
        print("\nInterrupted by user. Exiting.")
    finally:
        parser_.close()

if __name__ == '__main__':
    sys.exit(main())
