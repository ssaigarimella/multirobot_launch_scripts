#!/usr/bin/env python3
import socket
from struct import unpack

# Create UDP socket listening on all interfaces, port 51001
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # AF_INET + SOCK_DGRAM for UDP 
sock.bind(("0.0.0.0", 51001))                            # Bind to port 51001 on all interfaces

print("Listening for Vicon UDP packets on port 51001…")

while True:
    data, addr = sock.recvfrom(256)  # Read up to 256 bytes
    # Unpack first 6 doubles: x, y, z, rx, ry, rz (adjust offsets if your packet differs)
    x, = unpack('d', data[32:40])
    y, = unpack('d', data[40:48])
    z, = unpack('d', data[48:56])
    rx, = unpack('d', data[56:64])
    ry, = unpack('d', data[64:72])
    rz, = unpack('d', data[72:80])
    print(f"Pose: x={x:.3f}, y={y:.3f}, z={z:.3f}, rx={rx:.5f}, ry={ry:.5f}, rz={rz:.5f}")
