# Python-UDP-Parsing
Python code for accessing the UDP stream output by Vicon Tracker and parsing.

Vicon Tracker outputs a generic UDP stream that can be accessed without using the Vicon DataStream SDK. In embedded applications or where use of this SDK is not possible or undesired, it is possible to simply parse this UDP stream and extract the relevant Vicon data. DataBlock.h, in the Vicon Tracker installation folder (specifically C:\Program Files\Vicon\Tracker3.7\Simulink\UDP in the IFL PCs) describes the format of these UDP messages. 

This repo contains 2 simple scripts, both written by Nick Zhang, for accessing and parsing these UDP messages:

SimpleSingleObjectUDP.py accesses the UDP stream, parses it to extract a single object's 6 position and orientation values, then prints to the terminal.

MultithreadAsynchronousUDP.py extends functionality by implementing multi-threading and the ability to handle asynchronous UDP and program execution rates.
