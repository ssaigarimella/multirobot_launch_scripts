#!/usr/bin/env python3
import socket
from struct import unpack
from time import time
from collections import deque

# === Configuration ===
use_header_timestamp = False   # Set to True to use frame number diff for frequency
rolling_window_sec = 2.0       # Time window in seconds for average frequency estimate
# =======================

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(("0.0.0.0", 51001))

print("Listening for Vicon UDP packets on port 51001…")

last_recv_time = None
last_frame_num = None

recv_times = deque()  # stores (timestamp, frame_num)

while True:
    data, addr = sock.recvfrom(256)
    now = time()

    # Unpack pose data
    x, = unpack('d', data[32:40])
    y, = unpack('d', data[40:48])
    z, = unpack('d', data[48:56])
    rx, = unpack('d', data[56:64])
    ry, = unpack('d', data[64:72])
    rz, = unpack('d', data[72:80])

    # Unpack frame number from bytes 0–4
    frame_num, = unpack('<i', data[0:4])

    # Print pose
    print(f"Pose: x={x:.3f}, y={y:.3f}, z={z:.3f}, "
          f"rx={rx:.5f}, ry={ry:.5f}, rz={rz:.5f} | Frame: {frame_num}")

    # === Frequency Calculation ===
    if use_header_timestamp:
        # Use frame number difference for frequency
        if last_frame_num is not None:
            frame_diff = frame_num - last_frame_num
            time_diff = now - last_recv_time if last_recv_time else 0
            frequency = frame_diff / time_diff if time_diff > 0 else 0
            print(f"[Header-based] ΔFrame: {frame_diff}, ΔTime: {time_diff:.6f}s | Frequency: {frequency:.2f} Hz")
        last_frame_num = frame_num
        last_recv_time = now
    else:
        # Instantaneous frequency
        if last_recv_time is not None:
            delay = now - last_recv_time
            frequency_wall = 1.0 / delay if delay > 0 else 0.0
            print(f"[Wall-clock] ΔTime: {delay:.6f}s | Instantaneous Frequency: {frequency_wall:.2f} Hz")
        last_recv_time = now

        # Rolling average frequency
        recv_times.append(now)
        # Remove timestamps outside rolling window
        while recv_times and (now - recv_times[0]) > rolling_window_sec:
            recv_times.popleft()

        if len(recv_times) > 1:
            avg_frequency_wall = (len(recv_times) - 1) / (recv_times[-1] - recv_times[0])
            print(f"[Wall-clock] Rolling Avg Frequency ({rolling_window_sec:.1f}s): {avg_frequency_wall:.2f} Hz")
