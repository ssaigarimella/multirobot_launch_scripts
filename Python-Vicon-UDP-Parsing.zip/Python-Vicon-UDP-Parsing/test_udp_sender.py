import socket
import time

# IP of the Jetson (or the receiver device)
TARGET_IP = "192.168.0.86"  # replace with receiver's IP
TARGET_PORT = 51001

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

try:
    print("Sending UDP packets at 50 Hz...")
    while True:
        message = "Hello from sender at 50Hz"
        sock.sendto(message.encode(), (TARGET_IP, TARGET_PORT))
        time.sleep(0.02)  # 1 / 50 Hz
except KeyboardInterrupt:
    print("\nSender stopped.")
finally:
    sock.close()
